import React, { useEffect, useRef, useState } from 'react';

interface ParticleTextProps {
  text?: string;
  className?: string;
  particleColor?: string;
  particleSize?: number;
  fontSize?: number;
  interactive?: boolean;
}

interface Particle {
  x: number;
  y: number;
  originX: number;
  originY: number;
  vx: number;
  vy: number;
  radius: number;
  baseRadius: number;
  color: string;
  alpha: number;
  friction: number;
  spring: number;
}

export const ParticleText: React.FC<ParticleTextProps> = ({
  text = 'SPRITE',
  className = '',
  particleSize = 2.4,
  interactive = true,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const isVisibleRef = useRef<boolean>(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d', { alpha: true });
    if (!ctx) return;

    let animationFrameId: number;
    let particles: Particle[] = [];
    let width = 0;
    let height = 0;

    const mouse = {
      x: -1000,
      y: -1000,
      radius: 95,
      isActive: false,
    };

    const colorPalette = [
      '#FFFFFF',
      '#7CF7B3',
      '#A7F3D0',
      '#E0FFE8',
      '#6EE7B7',
    ];

    const initParticles = () => {
      if (!container || !canvas) return;
      const rect = container.getBoundingClientRect();
      width = Math.floor(rect.width);
      height = Math.floor(rect.height);

      if (width <= 20 || height <= 20) return;

      const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
      canvas.width = Math.floor(width * dpr);
      canvas.height = Math.floor(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

      try {
        const offscreen = document.createElement('canvas');
        const offCtx = offscreen.getContext('2d');
        if (!offCtx) return;

        offscreen.width = width;
        offscreen.height = height;

        const calculatedFontSize = Math.min(Math.floor(width * 0.22), Math.floor(height * 0.75));
        if (calculatedFontSize <= 0) return;

        offCtx.font = `900 ${calculatedFontSize}px 'Lilita One', Montserrat, sans-serif`;
        offCtx.textAlign = 'center';
        offCtx.textBaseline = 'middle';
        offCtx.fillStyle = '#FFFFFF';
        offCtx.fillText(text, width / 2, height / 2 + calculatedFontSize * 0.05);

        const imgData = offCtx.getImageData(0, 0, width, height);
        const data = imgData.data;

        particles = [];
        const step = Math.max(4, Math.floor(calculatedFontSize / 22));

        for (let y = 0; y < height; y += step) {
          for (let x = 0; x < width; x += step) {
            const index = (y * width + x) * 4;
            const alpha = data[index + 3];
            if (alpha > 128) {
              const color = colorPalette[Math.floor(Math.random() * colorPalette.length)];
              const baseRad = (Math.random() * 0.8 + 0.6) * particleSize;
              particles.push({
                x: x + (Math.random() - 0.5) * 30,
                y: y + (Math.random() - 0.5) * 30,
                originX: x,
                originY: y,
                vx: (Math.random() - 0.5) * 1.5,
                vy: (Math.random() - 0.5) * 1.5,
                radius: baseRad,
                baseRadius: baseRad,
                color,
                alpha: Math.random() * 0.35 + 0.65,
                friction: 0.88,
                spring: 0.065,
              });
            }
          }
        }
      } catch {
        // Fallback
      }
    };

    initParticles();

    // IntersectionObserver to pause when not in view (Fixes lag!)
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          isVisibleRef.current = entry.isIntersecting;
          if (entry.isIntersecting) {
            cancelAnimationFrame(animationFrameId);
            animationFrameId = requestAnimationFrame(render);
          }
        });
      },
      { threshold: 0.05 }
    );
    observer.observe(container);

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouse.x = e.clientX - rect.left;
      mouse.y = e.clientY - rect.top;
      mouse.isActive = true;
    };

    const handleTouchMove = (e: TouchEvent) => {
      if (e.touches.length > 0) {
        const rect = canvas.getBoundingClientRect();
        mouse.x = e.touches[0].clientX - rect.left;
        mouse.y = e.touches[0].clientY - rect.top;
        mouse.isActive = true;
      }
    };

    const handleMouseLeave = () => {
      mouse.x = -1000;
      mouse.y = -1000;
      mouse.isActive = false;
    };

    if (interactive) {
      container.addEventListener('mousemove', handleMouseMove);
      container.addEventListener('mouseleave', handleMouseLeave);
      container.addEventListener('touchmove', handleTouchMove, { passive: true });
      container.addEventListener('touchend', handleMouseLeave);
    }

    let time = 0;

    const render = () => {
      if (!isVisibleRef.current) return;

      time += 0.025;
      ctx.clearRect(0, 0, width, height);

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];

        const wobbleX = Math.sin(time + p.originY * 0.05) * 0.5;
        const wobbleY = Math.cos(time + p.originX * 0.05) * 0.5;

        if (interactive && mouse.isActive) {
          const dx = mouse.x - p.x;
          const dy = mouse.y - p.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < mouse.radius && dist > 0) {
            const force = (mouse.radius - dist) / mouse.radius;
            const angle = Math.atan2(dy, dx);
            p.vx -= Math.cos(angle) * force * 1.8;
            p.vy -= Math.sin(angle) * force * 1.8;
          }
        }

        const springX = (p.originX + wobbleX - p.x) * p.spring;
        const springY = (p.originY + wobbleY - p.y) * p.spring;

        p.vx = (p.vx + springX) * p.friction;
        p.vy = (p.vy + springY) * p.friction;

        p.x += p.vx;
        p.y += p.vy;

        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.alpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
      }

      animationFrameId = requestAnimationFrame(render);
    };

    return () => {
      observer.disconnect();
      cancelAnimationFrame(animationFrameId);
      if (interactive) {
        container.removeEventListener('mousemove', handleMouseMove);
        container.removeEventListener('mouseleave', handleMouseLeave);
        container.removeEventListener('touchmove', handleTouchMove);
        container.removeEventListener('touchend', handleMouseLeave);
      }
    };
  }, [interactive, particleSize, text]);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full overflow-hidden select-none pointer-events-auto ${className}`}
    >
      <canvas ref={canvasRef} className="w-full h-full block" />
    </div>
  );
};
