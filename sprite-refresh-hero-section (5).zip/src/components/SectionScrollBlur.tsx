import React, { useRef } from 'react';
import { motion, useScroll, useTransform, MotionValue } from 'motion/react';

interface SectionScrollBlurProps {
  /**
   * Position of the progressive blur overlay
   * 'bottom': blurs the bottom exit zone of a section
   * 'top': blurs the top entrance zone
   * 'seam': bidirectional seam blur between two sections
   */
  position?: 'bottom' | 'top' | 'seam';
  /**
   * Height of the blur zone (e.g. '120px', '160px', '220px')
   */
  height?: string | number;
  /**
   * Maximum blur radius in pixels
   */
  maxBlur?: number;
  /**
   * Custom target ref to observe scroll intersection
   */
  targetRef?: React.RefObject<HTMLElement | null>;
  /**
   * Optional custom scroll progress MotionValue
   */
  scrollProgress?: MotionValue<number>;
  /**
   * Optional container className
   */
  className?: string;
  /**
   * Tint color overlay (e.g. 'rgba(109, 178, 234, 0.25)')
   */
  tintColor?: string;
}

/**
 * SectionScrollBlur (ScrollBlurEssential)
 * Creates a progressive multi-tier optical blur gradient at section intersection boundaries.
 * As sections scroll and intersect, it softly diffuses lower/transitional elements so
 * the active section content stays focused and crisp.
 */
export const SectionScrollBlur: React.FC<SectionScrollBlurProps> = ({
  position = 'bottom',
  height = '180px',
  maxBlur = 16,
  targetRef,
  scrollProgress,
  className = '',
  tintColor = 'rgba(98, 185, 243, 0.15)',
}) => {
  const localRef = useRef<HTMLDivElement>(null);
  const activeRef = targetRef || localRef;

  const { scrollYProgress: defaultProgress } = useScroll({
    target: activeRef,
    offset: ['start end', 'end start'],
  });

  const progress = scrollProgress || defaultProgress;

  // Progressive scroll-linked blur opacity:
  // Fades in gently as the lower section boundary scrolls toward viewport exit
  const blurOpacity = useTransform(progress, (p: number) => {
    if (position === 'bottom') {
      // Activates when scrolling down past 45% of the section
      if (p < 0.35) return 0.2;
      if (p > 0.85) return 1;
      return 0.2 + (0.8 * (p - 0.35)) / 0.5;
    } else if (position === 'top') {
      if (p < 0.2) return 1;
      if (p > 0.65) return 0.2;
      return 1 - (0.8 * (p - 0.2)) / 0.45;
    } else {
      // Seam: peak intensity at intersection mid-point
      return Math.min(1, Math.max(0.3, Math.sin(p * Math.PI)));
    }
  });

  // Calculate position classes
  const positionStyle: React.CSSProperties = {
    position: 'absolute',
    left: 0,
    right: 0,
    height: typeof height === 'number' ? `${height}px` : height,
    pointerEvents: 'none',
    zIndex: 25,
  };

  if (position === 'bottom') {
    positionStyle.bottom = 0;
  } else if (position === 'top') {
    positionStyle.top = 0;
  } else {
    positionStyle.bottom = typeof height === 'number' ? `-${height / 2}px` : '-90px';
  }

  // Progressive blur layers (tier-stepped for natural optical dispersion)
  const blurTiers = [
    { blur: maxBlur * 0.15, maskStart: 0, maskEnd: 30, opacity: 0.9 },
    { blur: maxBlur * 0.35, maskStart: 15, maskEnd: 55, opacity: 0.85 },
    { blur: maxBlur * 0.65, maskStart: 35, maskEnd: 80, opacity: 0.8 },
    { blur: maxBlur, maskStart: 55, maskEnd: 100, opacity: 0.95 },
  ];

  const maskDirection = position === 'top' ? 'to top' : 'to bottom';

  return (
    <motion.div
      ref={localRef}
      style={{
        ...positionStyle,
        opacity: blurOpacity,
      }}
      className={`overflow-hidden select-none will-change-[opacity] ${className}`}
      aria-hidden="true"
    >
      {/* 1. Progressive Multi-Tier Frosted Backdrop Blur Layers */}
      {blurTiers.map((tier, idx) => {
        const maskGradient = `linear-gradient(${maskDirection}, transparent 0%, transparent ${tier.maskStart}%, black ${tier.maskEnd}%, black 100%)`;
        return (
          <div
            key={idx}
            className="absolute inset-0 w-full h-full pointer-events-none"
            style={{
              backdropFilter: `blur(${tier.blur}px)`,
              WebkitBackdropFilter: `blur(${tier.blur}px)`,
              maskImage: maskGradient,
              WebkitMaskImage: maskGradient,
              opacity: tier.opacity,
            }}
          />
        );
      })}

      {/* 2. Soft Ambient Tint Gradient for Seamless Section Color Cohesion */}
      <div
        className="absolute inset-0 w-full h-full pointer-events-none"
        style={{
          background: `linear-gradient(${maskDirection}, transparent 0%, ${tintColor} 70%, rgba(98, 185, 243, 0.45) 100%)`,
        }}
      />
    </motion.div>
  );
};
