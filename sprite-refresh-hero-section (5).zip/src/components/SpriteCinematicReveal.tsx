import React, { useEffect, useState } from 'react';
import { motion } from 'motion/react';
import { spriteAudio } from '../utils/audio';

interface CinematicRevealProps {
  onComplete?: () => void;
  onTransitionStart?: () => void;
}

const NUM_COLUMNS = 5;

export const SpriteCinematicReveal: React.FC<CinematicRevealProps> = ({
  onComplete,
  onTransitionStart,
}) => {
  const [isExiting, setIsExiting] = useState<boolean>(false);
  const [isDone, setIsDone] = useState<boolean>(false);

  useEffect(() => {
    // Immediately start the snappy reveal animation on mount
    const exitTimer = setTimeout(() => {
      setIsExiting(true);
      spriteAudio.playRefreshBurst();
      if (onTransitionStart) onTransitionStart();
    }, 120); // Quick micro-tick so the browser registers the initial frame

    // Complete and unmount once columns finish sliding upward
    const completeTimer = setTimeout(() => {
      setIsDone(true);
      if (onComplete) onComplete();
    }, 850);

    return () => {
      clearTimeout(exitTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete, onTransitionStart]);

  if (isDone) return null;

  return (
    <div
      id="sprite-framer-fast-loader"
      className="fixed inset-0 z-50 pointer-events-none select-none flex items-center justify-center overflow-hidden w-screen h-screen"
    >
      {/* 
        STAGGERED VERTICAL SHUTTER COLUMNS (BALANCED SPRITE GREEN)
        Directly slides upward in a rapid, fluid stagger to unveil the site instantly
      */}
      <div className="absolute inset-0 w-full h-full flex flex-row pointer-events-none z-10">
        {Array.from({ length: NUM_COLUMNS }).map((_, index) => {
          return (
            <motion.div
              key={`col-${index}`}
              initial={{ y: '0%' }}
              animate={{
                y: isExiting ? '-100%' : '0%',
              }}
              transition={{
                duration: 0.65,
                delay: index * 0.05, // Fast snappy stagger
                ease: [0.76, 0, 0.24, 1], // Buttery Framer bezier
              }}
              className="relative h-full flex-1 bg-[#00A850] border-r border-[#009244]/40 last:border-r-0 shadow-[0_0_15px_rgba(0,0,0,0.03)]"
            />
          );
        })}
      </div>
    </div>
  );
};
