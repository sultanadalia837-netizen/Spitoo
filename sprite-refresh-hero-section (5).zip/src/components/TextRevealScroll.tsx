import React from 'react';
import { motion, MotionValue, useTransform } from 'motion/react';

interface TextRevealWordProps {
  word: string;
  progress: MotionValue<number>;
  range: [number, number];
  className?: string;
}

const TextRevealWord: React.FC<TextRevealWordProps> = ({
  word,
  progress,
  range,
  className = '',
}) => {
  const [start, end] = range;

  // Faster, snappier text highlight curve on scroll
  const opacity = useTransform(progress, [start, end], [0.22, 1]);
  const y = useTransform(progress, [start, end], [4, 0]);
  const blur = useTransform(progress, (val: number) => {
    if (val <= start) return 'blur(2px)';
    if (val >= end) return 'blur(0px)';
    const t = (val - start) / (end - start);
    return `blur(${2 * (1 - t)}px)`;
  });

  // Dynamic light emission on active scroll
  const textShadow = useTransform(progress, (val: number) => {
    if (val < start) return '0 2px 8px rgba(0, 0, 0, 0.15)';
    if (val >= end) return '0 4px 16px rgba(255, 255, 255, 0.25), 0 2px 8px rgba(0, 0, 0, 0.2)';
    const t = (val - start) / (end - start);
    return `0 ${2 + 2 * t}px ${8 + 8 * t}px rgba(255, 255, 255, ${0.25 * t}), 0 2px 8px rgba(0, 0, 0, 0.2)`;
  });

  return (
    <motion.span
      style={{
        opacity,
        y,
        filter: blur,
        textShadow,
      }}
      className={`inline-block mr-[0.24em] last:mr-0 will-change-[opacity,transform,filter] transition-[color] duration-150 ${className}`}
    >
      {word}
    </motion.span>
  );
};

interface TextRevealScrollProps {
  text: string;
  progress: MotionValue<number>;
  range?: [number, number];
  className?: string;
  textClassName?: string;
  tag?: 'h1' | 'h2' | 'h3' | 'p' | 'span';
}

export const TextRevealScroll: React.FC<TextRevealScrollProps> = ({
  text,
  progress,
  range = [0, 1],
  className = '',
  textClassName = '',
  tag: Tag = 'h2',
}) => {
  const words = text.trim().split(/\s+/);
  const totalWords = words.length;
  const [startRange, endRange] = range;
  const rangeSpan = endRange - startRange;

  return (
    <Tag className={`select-none overflow-visible ${className}`}>
      <span className={`inline-flex flex-wrap items-center justify-center ${textClassName}`}>
        {words.map((word, i) => {
          // Snappier individual word slice so text highlights briskly with scroll
          const wordStart = startRange + (i / totalWords) * rangeSpan * 0.75;
          const wordEnd = Math.min(endRange, wordStart + (rangeSpan / totalWords) * 1.1);

          return (
            <TextRevealWord
              key={`${word}-${i}`}
              word={word}
              progress={progress}
              range={[wordStart, wordEnd]}
            />
          );
        })}
      </span>
    </Tag>
  );
};
