import React from 'react';
import { motion } from 'motion/react';
import { MobileNavbar } from './MobileNavbar';
import { SpriteInteractiveCTA } from './SpriteInteractiveCTA';
import { BubbleAtmosphere } from './BubbleAtmosphere';
import { ProductSpotlightReveal } from './ProductSpotlightReveal';
import { SectionScrollBlur } from './SectionScrollBlur';

const BACKGROUND_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753603/1_20260826_200445_0000_u7lbnw.png';
const FOREGROUND_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787753604/file_00000000689081fdba99b19e7dbc6094_hf8odj.png';
const REVEAL_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787799318/file_00000000db2882098893b24b1616b047_uw6bka.png';
const SKY_CLOUD_MASK_IMG = 'https://res.cloudinary.com/dwinu9eul/image/upload/v1787815925/file_00000000d2848211a74f06c8f2a75677_vyxyww.png';

interface MobileHeroProps {
  revealTrigger?: number;
}

export const MobileHero: React.FC<MobileHeroProps> = () => {
  const headlineLetters = ['R', 'E', 'F', 'R', 'E', 'S', 'H'];

  return (
    <div
      id="sprite-mobile-hero"
      className="relative w-full min-h-screen h-[100dvh] overflow-visible bg-[#6db2ea] flex flex-col justify-between select-none"
    >
      {/* 1. Dynamic Scenic Background with Silky Zoom & Ambient Glow */}
      <motion.div
        initial={{ scale: 1.08, opacity: 0.85 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ duration: 1.6, ease: [0.19, 1, 0.22, 1] }}
        className="absolute inset-0 w-full h-full z-0 overflow-hidden"
      >
        <img
          src={BACKGROUND_IMG}
          alt="Scenic Sprite Sky Background"
          className="w-full h-full object-cover object-center pointer-events-none"
          crossOrigin="anonymous"
          loading="eager"
        />
        {/* Ambient Soft White Light Bloom behind product */}
        <motion.div
          initial={{ scale: 0.5, opacity: 0 }}
          animate={{ scale: [0.5, 1.2, 1], opacity: [0, 0.5, 0.3] }}
          transition={{ duration: 2.0, ease: [0.19, 1, 0.22, 1] }}
          className="absolute left-1/2 top-[48%] -translate-x-1/2 -translate-y-1/2 w-[340px] h-[340px] rounded-full pointer-events-none"
          style={{
            background:
              'radial-gradient(circle, rgba(255,255,255,0.45) 0%, rgba(255,248,220,0.2) 35%, rgba(255,255,255,0) 70%)',
          }}
        />
      </motion.div>

      {/* Atmospheric Fizzing Bubbles */}
      <BubbleAtmosphere />

      {/* 2. Mobile Frosted Glass Navbar */}
      <MobileNavbar />

      {/* 3. Main Mobile Interactive Content Area */}
      <div className="relative z-10 w-full flex-1 flex flex-col items-center justify-center px-4 pt-20 sm:pt-22 pb-4 landscape:pt-11 landscape:pb-1">
        {/* Main 3D Headline "REFRESH" */}
        <div className="w-full text-center pointer-events-none mt-2 sm:mt-3 mb-0 sm:mb-1 landscape:mt-0 landscape:-mb-1">
          <h1
            className="font-lilita flex items-center justify-center leading-none select-none tracking-[-0.04em] text-[clamp(52px,16vw,96px)] landscape:text-[clamp(30px,6.5vw,44px)]"
          >
            {headlineLetters.map((char, index) => (
              <span
                key={`${char}-${index}`}
                className="inline-block overflow-hidden pb-2 landscape:pb-0.5"
                style={{ perspective: '600px' }}
              >
                <motion.span
                  className="inline-block text-headline-3d"
                  initial={{
                    y: 120,
                    opacity: 0,
                    rotateX: 45,
                    filter: 'blur(8px)',
                  }}
                  animate={{
                    y: 0,
                    opacity: 1,
                    rotateX: 0,
                    filter: 'blur(0px)',
                  }}
                  transition={{
                    duration: 1.2,
                    delay: 0.15 + index * 0.05,
                    ease: [0.19, 1, 0.22, 1],
                  }}
                >
                  {char}
                </motion.span>
              </span>
            ))}
          </h1>
        </div>

        {/* Floating Sprite Can & Grass Island with Flanking Sub-Headlines */}
        <div className="relative w-full max-w-[380px] aspect-[4/3] landscape:max-w-[240px] landscape:aspect-[16/10] landscape:max-h-[140px] flex items-center justify-center my-auto landscape:my-0.5">
          {/* Sub-headline "YOUR" (Left) */}
          <motion.div
            initial={{ opacity: 0, x: -40, rotate: -8, filter: 'blur(6px)' }}
            animate={{ opacity: 1, x: 0, rotate: 0, filter: 'blur(0px)' }}
            transition={{ duration: 1.2, delay: 0.45, ease: [0.19, 1, 0.22, 1] }}
            className="absolute left-1 landscape:left-0 top-[28%] z-10 pointer-events-none"
          >
            <span className="font-lilita text-[clamp(28px,8vw,48px)] landscape:text-[22px] leading-none text-subheadline-3d">
              YOUR
            </span>
          </motion.div>

          {/* Sub-headline "WORLD" (Right) */}
          <motion.div
            initial={{ opacity: 0, x: 40, rotate: 8, filter: 'blur(6px)' }}
            animate={{ opacity: 1, x: 0, rotate: 0, filter: 'blur(0px)' }}
            transition={{ duration: 1.2, delay: 0.55, ease: [0.19, 1, 0.22, 1] }}
            className="absolute right-1 landscape:right-0 top-[28%] z-10 pointer-events-none"
          >
            <span className="font-lilita text-[clamp(28px,8vw,48px)] landscape:text-[22px] leading-none text-subheadline-3d">
              WORLD
            </span>
          </motion.div>

          {/* Foreground 3D Sprite Can with Touch Scratch Spotlight Reveal */}
          <div className="relative w-full h-full z-20 pointer-events-auto">
            <ProductSpotlightReveal
              baseImage={FOREGROUND_IMG}
              revealImage={REVEAL_IMG}
              alt="Sprite Can on Moss Island Mobile"
              spotlightRadius={130}
            />
          </div>
        </div>

        {/* Floating Clouds Bottom Overlay */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, delay: 0.3 }}
          className="absolute -bottom-10 left-0 right-0 h-40 pointer-events-none z-30"
        >
          <img
            src={SKY_CLOUD_MASK_IMG}
            alt=""
            className="w-full h-full object-contain object-bottom scale-110"
            crossOrigin="anonymous"
            loading="eager"
          />
        </motion.div>

        {/* Interactive CTA Button */}
        <motion.div
          initial={{ opacity: 0, y: 30, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          transition={{ duration: 0.9, delay: 0.65, ease: [0.34, 1.4, 0.64, 1] }}
          className="relative z-35 mt-1 sm:mt-2 mb-2 landscape:mt-0 landscape:mb-0 pointer-events-auto"
        >
          <SpriteInteractiveCTA
            onExplore={() => {
              const aboutEl = document.getElementById('about');
              aboutEl?.scrollIntoView({ behavior: 'smooth' });
            }}
          />
        </motion.div>

        {/* Mobile Subheadline (Shifted upward for crisp layout) */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.8 }}
          className="relative z-30 text-center mt-1"
        >
          <p className="text-white/85 text-[11px] font-montserrat tracking-wide">
            Crisp citrus. Cold refresh. Nothing ordinary.
          </p>
        </motion.div>
      </div>

      {/* Smooth scroll blur boundary */}
      <SectionScrollBlur
        position="bottom"
        height={120}
        maxBlur={10}
        tintColor="rgba(109, 178, 234, 0.2)"
      />
    </div>
  );
};
